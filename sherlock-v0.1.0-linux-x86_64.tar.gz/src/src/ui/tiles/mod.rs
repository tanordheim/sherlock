pub mod util;
pub mod app;
pub mod bulk_text;
pub mod calc;
pub mod web;

pub struct Tile{}
