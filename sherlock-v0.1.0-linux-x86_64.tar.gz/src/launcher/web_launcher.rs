

#[derive(Clone, Debug)]
pub struct Web{
    pub icon: String,
    pub engine: String,
}

