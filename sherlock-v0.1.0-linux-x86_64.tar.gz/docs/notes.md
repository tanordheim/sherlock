generate gresources:
glib-compile-resources --target=resources.gresources --sourcedir=resources resources/resources.gresources.xml
